# Unity Minecraft Clone

A very basic minecraft clone made in 24 hours

[Here's the youtube video showing the development](https://youtu.be/Nj8gt_92c-M)
